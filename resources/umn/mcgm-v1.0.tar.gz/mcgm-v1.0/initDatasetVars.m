function [datasetName, NMAE_factor, numTrainUsers] = initDatasetVars(datasetNameI)
    
    if (strcmpi(datasetNameI,'MovieLens1M'))
        datasetName = 'MovieLens1M';
        NMAE_factor = 1.6;
        numTrainUsers = 5000;   % only used for strong generalization

    elseif (strcmpi(datasetNameI,'EachMovie'))
        datasetName = 'EachMovie';
        NMAE_factor = 1.94;
        numTrainUsers = 30000;   % only used for strong generalization
    else
        error('Dataset name is not valid');
    end

end
