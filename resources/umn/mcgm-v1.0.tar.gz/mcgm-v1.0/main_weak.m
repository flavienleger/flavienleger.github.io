% ================= Main settings ==================

clear

% Number of iterations
num_itr = 15;


% Dataset: valid values are: MovieLens1M, EachMovie
% Values are case-insensitive

dataset = 'MovieLens1M';
% dataset = 'EachMovie';


% ==================================================





% ==================================================

[datasetName, NMAE_factor, numTrainUsers] = initDatasetVars(dataset); % numTrainUsers is only used for strong generalization, see main_strong.m
datasetFileName = sprintf('datasets/%s.mat',datasetName); 			  % path to dataset
load(datasetFileName);

im_ori = single(im_ori);

fprintf('Dataset: %s\n%0.f users\n%0.f items\n\n', datasetName, size(im_ori,1), size(im_ori,2));
fprintf('Number of iterations = %d\n\n', num_itr);

disp('Partitioning the data to training and test sets...');
[M_mask_train M_mask_test] = initWeakGeneralization(im_ori);


% Hold out ratings used for testing
im_train = im_ori .* M_mask_train;

% Initialization
im_rec = im_train + 3* (~M_mask_train);


for k = 1 : num_itr     
    
    fprintf('iter %2.0f       ', k);
    % M-step
    tic;
    [V_center M_cov] = getParam(im_rec);
	t=toc;
    fprintf('M-step: %.1fs\n', t);
   
    % E-step
    tic;
    im_rec = MAP_estimate(im_train, M_mask_train, V_center, M_cov);
    t=toc;
    fprintf('              E-step: %.1fs\n', t);

    % Error for this iteration
    nmae = weakGeneralizationProcedure(im_ori, postprocessing(im_rec,datasetName), M_mask_test, NMAE_factor);
    fprintf('Error:        NMAE = %.4f\n\n\n', nmae);
    
end


