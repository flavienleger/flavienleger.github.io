MCGM: Matrix completion with Gaussian models

Version 1.0, Oct. 23, 2010

====================================================================
Flavien Leger (flavien.leger[at]cims.nyu.edu)
Guoshen Yu (yu[at]cmap.polytechnique.fr)
Guillermo Sapiro (guille[at]umn.edu)

Please report bugs to Flavien Leger flavien.leger[at]cims.nyu.edu 

This directory contains the Matlab code for MCGM, an efficient
algorithm for matrix/table completion based on Gaussian models. 

Reference: 
F. L�ger, G.Yu, and G. Sapiro, Efficient Matrix Completion with Gaussian Models, submitted, arxiv.org/abs/1010.4050, Oct., 2010


====================================================================
= Usage =
To run the weak generalization procedure execute main_weak.m
To run the strong generalization procedure execute main_strong.m

To select a dataset edit main_weak.m or main_strong.m

For a description of testing procedures please see the aforementioned paper.


====================================================================
= Covariance matrix regularization parameter =

The algorithm contains one parameter: epsilon.

This parameter is used to ensure that the covariance matrix M_cov is invertible.
A small value epsilon is added to the eigenvalues:

 M_cov := M_cov + epsilon * Id


Default value: epsilon = 0.30

epsilon has been manually tuned to 0.30 for optimal results with the standard MovieLens1M and EachMovie datasets,
which contains ratings in [1,5] or [1,6]. 

No other dataset has been tested.

If the algorithm is tested with datasets containing values very different from 1,..,5 then epsilon might need 
to be changed for optimal results.

To modify epsilon edit the file getParam.m


====================================================================
= Acknowledgments =
We thank the GroupLens Research Group at the University of Minnesota for the MovieLens data set.



