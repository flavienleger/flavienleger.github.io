% Post-processing function: cutoff in [1 x] and round to nearest integer

function M_out = postprocessing(M_in, dataset)
	
	if (strcmpi(dataset,'MovieLens1M'))
		lowerBound = 1;
		upperBound = 5;
	elseif (strcmpi(dataset,'EachMovie'))
		lowerBound = 1;
		upperBound = 6;
	else
		error('Enter a valid dataset name');
	end

	M_out = min(M_in, upperBound);
	M_out = max(M_out, lowerBound);
	
	M_out = round(M_out);

end


