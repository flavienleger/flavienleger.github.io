% Compute error on test set points
% 
% INPUT: - im_ori = 2D matrix of all available ratings
%        - im_rec = approximation of im_ori after learning with train set
%        - M_mask_test = logical matrix of test set points
%        - NMAE_factor = normalization factor for computing NMAE
% 
% OUTPUT: NMAE error
% 
function nmae = weakGeneralizationProcedure(im_ori, im_rec, M_mask_test, NMAE_factor)
    
    original = im_ori(M_mask_test);     % column vector
    estimate = im_rec(M_mask_test);     % column vector
    
    nmae = 1/NMAE_factor * mean(abs(original - estimate));
    
end




