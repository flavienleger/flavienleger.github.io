% getParam: estimate mean and covariance
% The covariance matrix regularization parameter epsilon 
% may need to be changed for non-tested datasets.
% See README.txt for more information.

function [V_center M_cov] = getParam(im)

    dim = size(im,2);
    V_center = mean(im,1)';
    M_cov = cov(im);

    % Regularization parameter: M_cov := M_cov + epsilon * Id
    epsilon = 0.30;
  
    idx_diag = (0 : dim-1)*dim + (1 : dim);
    M_cov(idx_diag) = M_cov(idx_diag) + epsilon;

end
