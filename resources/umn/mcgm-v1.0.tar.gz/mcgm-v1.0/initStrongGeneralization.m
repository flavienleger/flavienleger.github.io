% Function used for getting random masks for strong generalization procedure
%
% INPUT:  - the 2D matrix of all available data,
%           (ratings must be ~= 0,
%           0 means no rating available.
%           Rows are users, columns are movies)
%         - the number of training users for stage 1
%
% OUTPUT: - the vector mask of the users training set (for stage 1)
%         - the mask of pixels used for training in stage 2
%         - the mask of pixels used for testing in stage 2

function [V_mask_training_users M_mask_train M_mask_test] = initStrongGeneralization(im_ori, numTrainUsers)

    [N1 N2] = size(im_ori);
    
    V_mask_training_users = false(N1,1);
    rp = randperm(N1);
    V_mask_training_users( rp(1:numTrainUsers) ) = true;

    [M_mask_train M_mask_test] = initWeakGeneralization( im_ori(~V_mask_training_users,:) );

end


