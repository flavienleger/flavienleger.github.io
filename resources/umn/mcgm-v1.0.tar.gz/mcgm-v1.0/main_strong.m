% ================= Main settings ==================

clear


% Number of iterations
num_itr = 15;


% Dataset: valid values are: MovieLens1M, EachMovie
% Values are case-insensitive

% dataset = 'MovieLens1M';
dataset = 'EachMovie';


% ==================================================





% ==================================================

[datasetName, NMAE_factor, numTrainUsers] = initDatasetVars(dataset);
datasetFileName = sprintf('datasets/%s.mat',datasetName);   % path to dataset
load(datasetFileName);

im_ori = single(im_ori);

fprintf('Dataset: %s\n%0.f users\n%0.f items\n\n', datasetName, size(im_ori,1), size(im_ori,2));
fprintf('Number of iterations = %d\n\n', num_itr);

disp('Partitioning the data to training and test sets...');
[V_mask_training_users M_mask_train M_mask_test] = initStrongGeneralization(im_ori, numTrainUsers);

im_stage1 = im_ori(V_mask_training_users,:);
M_mask_stage1 = (im_stage1 ~= 0);


% Initialization
im_rec = im_stage1 + 3* (~M_mask_stage1);

% Stage 1: training

fprintf('== STAGE 1 ==\n');
fprintf('%0.f users used for training\n\n\n', numTrainUsers);

for k = 1 : num_itr 
    
    fprintf('iter %2.0f,      ', k);
    % M-step
    tic;
    [V_center M_cov] = getParam(im_rec);
	t=toc;
    fprintf('M-step: %.1fs\n',t);

    if (k ~= num_itr)
		% E-step
		tic;
		im_rec = MAP_estimate(im_stage1, M_mask_stage1, V_center, M_cov);
		t=toc;
        fprintf('              E-step: %.1fs\n', t);
    end
    fprintf('\n');
    
end
fprintf('\n\n');



% Stage 2: predicting & testing

fprintf('== STAGE 2 ==\n\n');

im_ori_stage2 = im_ori(~V_mask_training_users,:);
im_train = M_mask_train .* im_ori_stage2;

% We do one E-step
tic;
im_rec = MAP_estimate(im_train, M_mask_train, V_center, M_cov);
t=toc;
fprintf('E-step: %.4fs\n',t);


nmae = weakGeneralizationProcedure(im_ori_stage2, postprocessing(im_rec,datasetName), M_mask_test, NMAE_factor);
fprintf('Error:        NMAE = %.4f\n', nmae);

    
