% Function used for initializing the weak generalization procedure
%
% Weak generalization procedure:
%  randomly select one rating per user for testing
%  and remove it from training set
% 
% INPUT: the 2D matrix of all available data,
%        ratings must be ~= 0,
%        0 means no rating available
%        rows are users, columns are items (movies)
% 
% OUTPUT: the mask of pixels used for training
%     and the mask of pixels used for testing
% 
function [M_mask_train M_mask_test] = initWeakGeneralization(M_data)
    [N1 N2] = size(M_data);
    
    M_mask_train = (M_data ~= 0);
    M_mask_test = false(N1,N2);
    
    for u=1:N1
        h = find(M_data(u,:) ~= 0);
        if ~isempty(h)
            v = ceil(rand(1) * length(h));
            M_mask_train(u,h(v)) = 0;
            M_mask_test(u,h(v)) = 1;
        end
    end
    
end

