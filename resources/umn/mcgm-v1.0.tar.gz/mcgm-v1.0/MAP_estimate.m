% MAP_estimate: estimate all ratings

function im_rec = MAP_estimate(im_train, M_mask, V_center, M_cov)

    im_rec = zeros(size(im_train), 'single');
    num_patches = size(im_train,1);

    for k = 1 : num_patches
        patch1 = im_train(k, :)';
        mask1 = M_mask(k, :)';

        A = M_cov(mask1,mask1);
        L = chol(A,'lower');	% A = L L'

        patch1_rec = patch1;
        tmp = L \ (patch1(mask1) - V_center(mask1));
        tmp = L' \ tmp;
        tmp = V_center(~mask1) + M_cov(~mask1,mask1) * tmp;	
        patch1_rec(~mask1) = tmp;

        im_rec(k, :) = patch1_rec';
    end

end
